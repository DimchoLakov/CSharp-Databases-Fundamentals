﻿namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        //Replace '.' with your Sql Server Name
        public const string ConnectionString = @"Server=DESKTOP-2G28R6E\SQLEXPRESS01;Database=SalesDb;Integrated Security=True;";
    }
}
