﻿using P02_DatabaseFirst.Data;
using P02_DatabaseFirst.Data.Models;

namespace P02_DatabaseFirst
{
    public class Startup
    {
        public static void Main()
        {
            
        }
    }
}
