﻿namespace P01_StudentSystem.Data.Configurations
{
    public class DbContextConfiguration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-2G28R6E\SQLEXPRESS01;" +
            "Database=StudentSystemDb;" +
            "Integrated Security=True;";
    }
}
